extends Node3D

const INTRO_DURATION: float = 13.0
const GOLD := Color(0.82, 0.62, 0.29)
const PALE_GOLD := Color(0.96, 0.82, 0.55)
const TEXT_LIGHT := Color(0.89, 0.89, 0.86)
const MUTED_TEXT := Color(0.68, 0.70, 0.72)
const CONFIG_PATH := "user://sparta_remastered.cfg"

var _camera: Camera3D
var _screen_mode: String = "boot"
var _intro_time: float = 0.0
var _intro_seen: bool = false
var _music_volume: float = 0.58
var _sfx_volume: float = 0.34
var _sfx_enabled: bool = true
var _config := ConfigFile.new()

var _ui_layer: CanvasLayer
var _intro_layer: Control
var _menu_layer: Control
var _intro_title: Label
var _intro_subtitle: Label
var _intro_progress: ProgressBar
var _skip_button: Button
var _menu_panel: PanelContainer
var _page_title: Label
var _page_subtitle: Label
var _page_body: Label
var _menu_buttons: VBoxContainer
var _dim_layer: ColorRect

var _menu_warriors: Array[Node3D] = []
var _player: Node3D
var _test_enemy: Node3D
var _attack_was_down: bool = false

func _ready() -> void:
    randomize()
    DisplayServer.window_set_title("SPARTA ARENA REMASTERED")
    _load_preferences()
    _build_3d_world()
    _build_ui()
    if _intro_seen:
        _show_menu()
        AudioManager.play_menu_ambience()
    else:
        _begin_intro()

func _process(delta: float) -> void:
    if _screen_mode == "intro":
        _intro_time += delta
        _update_intro_camera()
        if is_instance_valid(_intro_progress):
            _intro_progress.value = clampf(_intro_time / INTRO_DURATION * 100.0, 0.0, 100.0)
        if is_instance_valid(_intro_title):
            var fade := clampf(_intro_time / 1.4, 0.0, 1.0)
            _intro_title.modulate.a = fade
            _intro_subtitle.modulate.a = clampf((_intro_time - 0.7) / 1.4, 0.0, 1.0)
        if _intro_time >= INTRO_DURATION:
            _finish_intro()
    elif _screen_mode == "menu":
        _update_menu_camera(delta)
    elif _screen_mode == "test_arena":
        _update_test_arena(delta)

func _load_preferences() -> void:
    var err := _config.load(CONFIG_PATH)
    _intro_seen = false
    if err == OK:
        _intro_seen = bool(_config.get_value("progress", "intro_seen", false))
        _music_volume = float(_config.get_value("audio", "music_volume", 0.58))
        _sfx_volume = float(_config.get_value("audio", "sfx_volume", 0.34))
        _sfx_enabled = bool(_config.get_value("audio", "sfx_enabled", true))
    _music_volume = clampf(_music_volume, 0.0, 1.0)
    _sfx_volume = clampf(_sfx_volume, 0.0, 1.0)
    AudioManager.set_music_volume(_music_volume)
    AudioManager.set_sfx_volume(_sfx_volume)
    AudioManager.set_sfx_enabled(_sfx_enabled)

func _save_preferences() -> void:
    _config.set_value("progress", "intro_seen", _intro_seen)
    _config.set_value("audio", "music_volume", _music_volume)
    _config.set_value("audio", "sfx_volume", _sfx_volume)
    _config.set_value("audio", "sfx_enabled", _sfx_enabled)
    _config.save(CONFIG_PATH)

func _build_3d_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.012, 0.018, 0.032)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.38, 0.42, 0.54)
    env.ambient_light_energy = 0.62
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.glow_intensity = 0.26
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.name = "CinematicKeyLight"
    sun.rotation_degrees = Vector3(-43.0, -31.0, 0.0)
    sun.light_color = Color(1.0, 0.76, 0.52)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

    var fill := OmniLight3D.new()
    fill.name = "CoolArenaFill"
    fill.position = Vector3(0.0, 7.0, 7.0)
    fill.light_color = Color(0.28, 0.42, 0.78)
    fill.light_energy = 1.8
    fill.omni_range = 24.0
    add_child(fill)

    _add_cylinder(self, "ArenaFoundation", 15.0, 1.1, Vector3(0.0, -0.62, 0.0), Color(0.12, 0.105, 0.10), 64)
    _add_cylinder(self, "SandFloor", 12.25, 0.12, Vector3(0.0, -0.025, 0.0), Color(0.36, 0.29, 0.20), 64)
    _add_torus(self, "GoldArenaRing", 12.25, 11.97, Vector3(0.0, 0.055, 0.0), GOLD)
    _add_torus(self, "InnerStoneRing", 10.75, 10.63, Vector3(0.0, 0.052, 0.0), Color(0.35, 0.28, 0.19))

    # Stadium wall, repeated stone buttresses and tiered spectator silhouettes.
    for i in range(28):
        var angle := TAU * float(i) / 28.0
        var pos := Vector3(cos(angle) * 14.1, 0.45, sin(angle) * 14.1)
        var pillar := _add_box(self, "WallButtress_%02d" % i, Vector3(0.75, 2.25, 0.75), pos, Color(0.20, 0.18, 0.17))
        pillar.rotation.y = -angle
        _add_box(self, "WallCap_%02d" % i, Vector3(0.9, 0.18, 0.9), pos + Vector3(0.0, 1.18, 0.0), Color(0.31, 0.25, 0.19))

    # Distant low-poly mountains create a horizon without external art assets.
    for i in range(13):
        var angle := TAU * float(i) / 13.0
        var radius := 28.0 + float(i % 3) * 2.6
        var mountain := MeshInstance3D.new()
        mountain.name = "HorizonMountain_%02d" % i
        var mesh := CylinderMesh.new()
        mesh.top_radius = 0.15
        mesh.bottom_radius = 5.0 + float(i % 4) * 1.1
        mesh.height = 8.5 + float(i % 5) * 2.4
        mesh.radial_segments = 6
        mountain.mesh = mesh
        mountain.position = Vector3(cos(angle) * radius, mesh.height * 0.35 - 1.5, sin(angle) * radius)
        mountain.rotation.y = angle
        mountain.material_override = _material(Color(0.045 + 0.008 * float(i % 3), 0.065, 0.105 + 0.01 * float(i % 2), 1.0))
        add_child(mountain)

    # Decorative braziers use warm emissive material and small local lights.
    for i in range(8):
        var angle := TAU * float(i) / 8.0
        var p := Vector3(cos(angle) * 9.1, 0.0, sin(angle) * 9.1)
        _add_cylinder(self, "BrazierStand_%d" % i, 0.16, 1.1, p + Vector3(0.0, 0.55, 0.0), Color(0.24, 0.18, 0.12), 12)
        var flame_mat := _material(Color(1.0, 0.30, 0.07))
        flame_mat.emission_enabled = true
        flame_mat.emission = Color(1.0, 0.18, 0.035)
        flame_mat.emission_energy_multiplier = 2.0
        _add_sphere(self, "BrazierGlow_%d" % i, 0.19, p + Vector3(0.0, 1.22, 0.0), Color(1.0, 0.39, 0.07), flame_mat)
        var glow := OmniLight3D.new()
        glow.name = "BrazierLight_%d" % i
        glow.position = p + Vector3(0.0, 1.25, 0.0)
        glow.light_color = Color(1.0, 0.31, 0.08)
        glow.light_energy = 1.3
        glow.omni_range = 5.0
        add_child(glow)

    _camera = Camera3D.new()
    _camera.name = "CinematicCamera"
    _camera.fov = 47.0
    _camera.position = Vector3(0.0, 8.5, 31.0)
    add_child(_camera)
    _camera.current = true

    # The menu's three soldiers are visual dressing, not claimed as final character models.
    _menu_warriors.append(_make_warrior(Vector3(0.0, 0.0, 0.0), Color(0.37, 0.105, 0.08), Color(0.76, 0.21, 0.08)))
    _menu_warriors.append(_make_warrior(Vector3(-3.1, 0.0, -1.2), Color(0.19, 0.22, 0.26), Color(0.74, 0.55, 0.22)))
    _menu_warriors.append(_make_warrior(Vector3(3.1, 0.0, -1.5), Color(0.28, 0.21, 0.13), Color(0.76, 0.21, 0.08)))
    _menu_warriors[0].rotation.y = -0.12
    _menu_warriors[1].rotation.y = 0.30
    _menu_warriors[2].rotation.y = -0.26

func _build_ui() -> void:
    _ui_layer = CanvasLayer.new()
    _ui_layer.name = "UI"
    add_child(_ui_layer)

    _dim_layer = ColorRect.new()
    _dim_layer.color = Color(0.008, 0.012, 0.025, 0.54)
    _dim_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_dim_layer)

    _intro_layer = Control.new()
    _intro_layer.name = "IntroLayer"
    _intro_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_intro_layer)

    _intro_title = _make_label("SPARTA ARENA", 72, PALE_GOLD)
    _intro_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _intro_title.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _intro_title.offset_left = 40.0
    _intro_title.offset_right = -40.0
    _intro_title.offset_top = 105.0
    _intro_title.offset_bottom = 200.0
    _intro_layer.add_child(_intro_title)

    _intro_subtitle = _make_label("KÜLLERDEN DOĞAN EFSANE", 23, TEXT_LIGHT)
    _intro_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _intro_subtitle.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _intro_subtitle.offset_left = 40.0
    _intro_subtitle.offset_right = -40.0
    _intro_subtitle.offset_top = 203.0
    _intro_subtitle.offset_bottom = 250.0
    _intro_layer.add_child(_intro_subtitle)

    _intro_progress = ProgressBar.new()
    _intro_progress.show_percentage = false
    _intro_progress.min_value = 0.0
    _intro_progress.max_value = 100.0
    _intro_progress.value = 0.0
    _intro_progress.anchor_left = 0.12
    _intro_progress.anchor_right = 0.88
    _intro_progress.anchor_top = 1.0
    _intro_progress.anchor_bottom = 1.0
    _intro_progress.offset_top = -28.0
    _intro_progress.offset_bottom = -20.0
    _intro_layer.add_child(_intro_progress)

    var intro_caption := _make_label("13 SANİYELİK SİNEMATİK AÇILIŞ", 15, MUTED_TEXT)
    intro_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    intro_caption.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    intro_caption.offset_left = 30.0
    intro_caption.offset_right = -30.0
    intro_caption.offset_top = -75.0
    intro_caption.offset_bottom = -42.0
    _intro_layer.add_child(intro_caption)

    _skip_button = _make_button("ATLA  ›", 180)
    _skip_button.anchor_left = 1.0
    _skip_button.anchor_right = 1.0
    _skip_button.anchor_top = 1.0
    _skip_button.anchor_bottom = 1.0
    _skip_button.offset_left = -235.0
    _skip_button.offset_right = -48.0
    _skip_button.offset_top = -108.0
    _skip_button.offset_bottom = -50.0
    _skip_button.pressed.connect(_on_skip_pressed)
    _intro_layer.add_child(_skip_button)

    _menu_layer = Control.new()
    _menu_layer.name = "MenuLayer"
    _menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_menu_layer)

    _menu_panel = PanelContainer.new()
    _menu_panel.name = "MenuPanel"
    _menu_panel.anchor_left = 0.045
    _menu_panel.anchor_right = 0.485
    _menu_panel.anchor_top = 0.06
    _menu_panel.anchor_bottom = 0.94
    _menu_panel.offset_left = 0.0
    _menu_panel.offset_right = 0.0
    _menu_panel.offset_top = 0.0
    _menu_panel.offset_bottom = 0.0
    var panel_style := StyleBoxFlat.new()
    panel_style.bg_color = Color(0.025, 0.032, 0.052, 0.92)
    panel_style.border_color = Color(0.51, 0.35, 0.15, 0.9)
    panel_style.set_border_width_all(2)
    panel_style.set_corner_radius_all(10)
    panel_style.set_content_margin_all(24.0)
    _menu_panel.add_theme_stylebox_override("panel", panel_style)
    _menu_layer.add_child(_menu_panel)

    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 16)
    margin.add_theme_constant_override("margin_right", 16)
    margin.add_theme_constant_override("margin_top", 12)
    margin.add_theme_constant_override("margin_bottom", 12)
    _menu_panel.add_child(margin)

    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 9)
    margin.add_child(content)

    _page_title = _make_label("SPARTA ARENA", 38, PALE_GOLD)
    content.add_child(_page_title)
    _page_subtitle = _make_label("REMASTERED • SPARTA WORLD", 14, MUTED_TEXT)
    content.add_child(_page_subtitle)
    var separator := HSeparator.new()
    content.add_child(separator)
    _page_body = _make_label("V57 kaynakları korunarak gerçek 3D sürüme taşınıyor.", 15, TEXT_LIGHT)
    _page_body.custom_minimum_size = Vector2(0.0, 58.0)
    _page_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    content.add_child(_page_body)

    _menu_buttons = VBoxContainer.new()
    _menu_buttons.add_theme_constant_override("separation", 6)
    _menu_buttons.size_flags_vertical = Control.SIZE_EXPAND_FILL
    content.add_child(_menu_buttons)

    _menu_layer.hide()

func _make_label(text_value: String, font_size: int, color: Color) -> Label:
    var label := Label.new()
    label.text = text_value
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.7))
    label.add_theme_constant_override("shadow_offset_x", 2)
    label.add_theme_constant_override("shadow_offset_y", 2)
    return label

func _make_button(label_text: String, min_width: int = 0) -> Button:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size = Vector2(float(min_width), 42.0)
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 16)
    button.add_theme_color_override("font_color", TEXT_LIGHT)
    button.add_theme_color_override("font_hover_color", PALE_GOLD)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.075, 0.09, 0.12, 0.94)
    normal.border_color = Color(0.39, 0.29, 0.16, 0.9)
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(6)
    normal.set_content_margin_all(7.0)
    button.add_theme_stylebox_override("normal", normal)
    var hover := normal.duplicate() as StyleBoxFlat
    hover.bg_color = Color(0.15, 0.13, 0.095, 0.98)
    hover.border_color = GOLD
    button.add_theme_stylebox_override("hover", hover)
    var pressed_style := normal.duplicate() as StyleBoxFlat
    pressed_style.bg_color = Color(0.20, 0.15, 0.085, 0.98)
    button.add_theme_stylebox_override("pressed", pressed_style)
    button.pressed.connect(_on_any_button_pressed)
    return button

func _add_menu_button(label_text: String, callback: Callable) -> void:
    var button := _make_button(label_text)
    button.pressed.connect(callback)
    _menu_buttons.add_child(button)

func _clear_menu_buttons() -> void:
    for child in _menu_buttons.get_children():
        child.queue_free()

func _set_page(title_value: String, subtitle_value: String, body_value: String) -> void:
    _menu_layer.show()
    _intro_layer.hide()
    _page_title.text = title_value
    _page_subtitle.text = subtitle_value
    _page_body.text = body_value
    _clear_menu_buttons()

func _show_menu() -> void:
    _screen_mode = "menu"
    _set_page("SPARTA ARENA", "REMASTERED • SPARTA WORLD", "Antik dünyanın karanlığında yeni bir efsane doğuyor. Bu paket, PC için 3D temelin başlangıcıdır; V57 sistemleri aşağıdaki kaynak arşivinde korunmuştur.")
    _add_menu_button("OYNA  /  MODLARI GÖR", _show_modes)
    _add_menu_button("KARAKTERLER", _show_characters)
    _add_menu_button("HARİTALAR", _show_maps)
    _add_menu_button("MAĞAZA  /  İKSİRLER", _show_shop_status)
    _add_menu_button("BAŞARIMLAR", _show_achievements_status)
    _add_menu_button("AYARLAR", _show_settings)
    _add_menu_button("TANITIMI OYNAT", _begin_intro)
    _add_menu_button("ÇIKIŞ", _quit_game)

func _show_modes() -> void:
    _screen_mode = "menu"
    _set_page("OYUN MODLARI", "V57 MEKANİK ENVANTERİ", "Bu menü kaynak envanteridir; aşağıdaki eski modlar henüz 3D oynanışa aktarılmadı. Şimdilik yalnızca teknik arena testine girilebilir.")
    _add_menu_button("KLASİK TUR  /  SONSUZ DÜŞMAN", _show_classic_endless_status)
    _add_menu_button("TEPENİN KRALI  /  BOSS SAVAŞLARI", _show_hill_boss_status)
    _add_menu_button("DÜNYA FETHİ  /  ŞEHİRLER  /  KUŞATMA", _show_world_conquest_status)
    _add_menu_button("DENİZ FETHİ  /  BALIKÇILIK", _show_sea_status)
    _add_menu_button("3D TEKNİK ARENA TESTİ", _start_test_arena)
    _add_menu_button("GERİ", _show_menu)

func _show_characters() -> void:
    _screen_mode = "menu"
    _set_page("KARAKTERLER", "3D MODEL TEMELİ", "Şu an sahnede üç geçici, prosedürel 3D Spartalı bulunur. V57 karakter listesi kaynakta korunmuştur; ayrıntılı karakter modelleri ve animasyonları henüz taşınmadı.")
    _add_menu_button("SPARTALI  —  3D TEST", _start_test_arena)
    _add_menu_button("V57 KARAKTER LİSTESİ / AKTARIM NOTU", _show_character_status)
    _add_menu_button("GERİ", _show_menu)

func _show_maps() -> void:
    _screen_mode = "menu"
    _set_page("HARİTALAR", "ARENA • ÇÖL • KAR • ORMAN • DENİZ", "Bu başlangıç sahnesinde yalnızca 3D arena çevresi vardır. V57 haritalarının her biri ayrı 3D çevreye dönüştürülecek; bu paket henüz tüm haritaları içermez.")
    _add_menu_button("ARENA TEKNİK TESTİ", _start_test_arena)
    _add_menu_button("V57 HARİTA ENVANTERİ", _show_map_status)
    _add_menu_button("GERİ", _show_menu)

func _show_shop_status() -> void:
    _show_legacy_status("Mağaza ve iksirler")

func _show_achievements_status() -> void:
    _show_legacy_status("Başarımlar")

func _show_classic_endless_status() -> void:
    _show_legacy_status("Klasik tur ve sonsuz düşman")

func _show_hill_boss_status() -> void:
    _show_legacy_status("Tepenin kralı ve boss savaşları")

func _show_world_conquest_status() -> void:
    _show_legacy_status("Dünya ve şehir fethi")

func _show_sea_status() -> void:
    _show_legacy_status("Deniz fethi ve balıkçılık")

func _show_character_status() -> void:
    _show_legacy_status("Karakter seçimi")

func _show_map_status() -> void:
    _show_legacy_status("Harita seçimi")

func _show_legacy_status(feature_name: String) -> void:
    _screen_mode = "menu"
    _set_page(feature_name.to_upper(), "PORT DURUMU", "Bu sistem V57 ZIP'indeki eski Pygame kaynaklarında yer alıyor. Kaynak kod korunmuştur; Godot tabanlı 3D sürüme henüz aktarılmış değildir. Sıradaki aşamada sistem davranışı tek tek yeniden yazılıp test edilecek.")
    _add_menu_button("MOD ENVANTERİ", _show_modes)
    _add_menu_button("ANA MENÜ", _show_menu)

func _show_settings() -> void:
    _screen_mode = "menu"
    _set_page("AYARLAR", "SES VE GÖRÜNTÜ", "Sesler düşük seviyede tasarlanmıştır. Sert UI click ve kılıç savurma sesi yoktur; UI için yumuşak dokunuş, çarpışma için daha tok ve kısık metal sesi kullanılır.")
    _add_menu_button("MÜZİK SESİ: %d%%" % int(round(_music_volume * 100.0)), _cycle_music_volume)
    _add_menu_button("EFEKT SESİ: %d%%" % int(round(_sfx_volume * 100.0)), _cycle_sfx_volume)
    _add_menu_button("EFEKT SESLERİ: %s" % ("AÇIK" if _sfx_enabled else "KAPALI"), _toggle_sfx)
    _add_menu_button("GERİ", _show_menu)

func _cycle_music_volume() -> void:
    _music_volume = 0.0 if _music_volume >= 0.99 else minf(1.0, _music_volume + 0.2)
    AudioManager.set_music_volume(_music_volume)
    _save_preferences()
    _show_settings()

func _cycle_sfx_volume() -> void:
    _sfx_volume = 0.0 if _sfx_volume >= 0.99 else minf(1.0, _sfx_volume + 0.2)
    AudioManager.set_sfx_volume(_sfx_volume)
    _save_preferences()
    _show_settings()

func _toggle_sfx() -> void:
    _sfx_enabled = not _sfx_enabled
    AudioManager.set_sfx_enabled(_sfx_enabled)
    _save_preferences()
    _show_settings()

func _on_any_button_pressed() -> void:
    AudioManager.play_ui()

func _on_skip_pressed() -> void:
    _finish_intro()

func _begin_intro() -> void:
    _screen_mode = "intro"
    _intro_time = 0.0
    _intro_progress.value = 0.0
    _intro_title.modulate.a = 0.0
    _intro_subtitle.modulate.a = 0.0
    _menu_layer.hide()
    _intro_layer.show()
    AudioManager.play_intro_score()

func _finish_intro() -> void:
    if _screen_mode != "intro":
        return
    _intro_seen = true
    _save_preferences()
    _show_menu()
    AudioManager.play_menu_ambience()

func _quit_game() -> void:
    get_tree().quit()

func _start_test_arena() -> void:
    _screen_mode = "test_arena"
    _menu_layer.hide()
    _intro_layer.hide()
    for warrior in _menu_warriors:
        warrior.hide()
    if is_instance_valid(_player):
        _player.queue_free()
    if is_instance_valid(_test_enemy):
        _test_enemy.queue_free()
    _player = _make_warrior(Vector3(0.0, 0.0, 4.0), Color(0.39, 0.11, 0.075), Color(0.82, 0.23, 0.075))
    _test_enemy = _make_warrior(Vector3(0.0, 0.0, -4.0), Color(0.20, 0.22, 0.24), Color(0.69, 0.53, 0.24))
    _test_enemy.scale = Vector3(1.05, 1.05, 1.05)
    _camera.position = Vector3(0.0, 6.2, 14.0)
    _camera.look_at(_player.position + Vector3(0.0, 1.1, -1.0), Vector3.UP)
    var help_layer := Control.new()
    help_layer.name = "TestHelp"
    help_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _menu_layer.add_child(help_layer)
    _menu_layer.show()
    _menu_panel.visible = false
    var hint := _make_label("3D TEST • WASD / OK TUŞLARI: HAREKET • SOL TIK: SESSİZ DARBE SESİ", 17, TEXT_LIGHT)
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    hint.offset_left = 30.0
    hint.offset_right = -30.0
    hint.offset_top = 20.0
    hint.offset_bottom = 60.0
    help_layer.add_child(hint)
    var back := _make_button("MENÜYE DÖN", 190)
    back.anchor_left = 1.0
    back.anchor_right = 1.0
    back.anchor_top = 1.0
    back.anchor_bottom = 1.0
    back.offset_left = -240.0
    back.offset_right = -42.0
    back.offset_top = -80.0
    back.offset_bottom = -28.0
    back.pressed.connect(_exit_test_arena)
    help_layer.add_child(back)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _exit_test_arena() -> void:
    _screen_mode = "menu"
    if is_instance_valid(_player):
        _player.queue_free()
    if is_instance_valid(_test_enemy):
        _test_enemy.queue_free()
    for child in _menu_layer.get_children():
        if child != _menu_panel:
            child.queue_free()
    _menu_panel.visible = true
    _show_menu()
    for warrior in _menu_warriors:
        warrior.show()

func _update_test_arena(delta: float) -> void:
    if not is_instance_valid(_player):
        return
    var direction := Vector3.ZERO
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        direction.z -= 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        direction.z += 1.0
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        direction.x -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        direction.x += 1.0
    if direction.length() > 0.01:
        direction = direction.normalized()
        _player.position += direction * 4.2 * delta
        _player.position.x = clampf(_player.position.x, -8.0, 8.0)
        _player.position.z = clampf(_player.position.z, -8.0, 8.0)
        _player.rotation.y = atan2(-direction.x, -direction.z)
    var attack_down := Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
    if attack_down and not _attack_was_down:
        AudioManager.play_muted_impact()
    _attack_was_down = attack_down
    var desired_camera := _player.position + Vector3(0.0, 5.6, 10.5)
    _camera.position = _camera.position.lerp(desired_camera, clampf(delta * 4.0, 0.0, 1.0))
    _camera.look_at(_player.position + Vector3(0.0, 1.0, -1.6), Vector3.UP)

func _update_intro_camera() -> void:
    var t := clampf(_intro_time / INTRO_DURATION, 0.0, 1.0)
    var angle := -0.9 + t * 2.2
    var radius := lerpf(25.0, 15.8, smoothstep(0.0, 1.0, t))
    var height := 8.5 + sin(t * TAU * 1.15) * 1.25
    _camera.position = Vector3(sin(angle) * radius, height, cos(angle) * radius)
    _camera.look_at(Vector3(0.0, 1.25, 0.0), Vector3.UP)

func _update_menu_camera(delta: float) -> void:
    if not is_instance_valid(_camera):
        return
    var t := float(Time.get_ticks_msec()) / 1000.0
    var desired := Vector3(sin(t * 0.10) * 2.2, 7.2 + sin(t * 0.16) * 0.25, 22.2 + cos(t * 0.08) * 1.0)
    _camera.position = _camera.position.lerp(desired, clampf(delta * 0.4, 0.0, 1.0))
    _camera.look_at(Vector3(0.0, 1.25, 0.0), Vector3.UP)

func _material(color: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.82
    return mat

func _add_box(parent: Node3D, object_name: String, dimensions: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_cylinder(parent: Node3D, object_name: String, radius: float, height: float, pos: Vector3, color: Color, segments: int = 24) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = segments
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_torus(parent: Node3D, object_name: String, outer_radius: float, inner_radius: float, pos: Vector3, color: Color) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := TorusMesh.new()
    mesh.outer_radius = outer_radius
    mesh.inner_radius = inner_radius
    mesh.rings = 72
    mesh.ring_segments = 12
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_sphere(parent: Node3D, object_name: String, radius: float, pos: Vector3, color: Color, material: StandardMaterial3D = null) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    item.mesh = mesh
    item.position = pos
    item.material_override = material if material != null else _material(color)
    parent.add_child(item)
    return item

func _make_warrior(pos: Vector3, armor_color: Color, crest_color: Color) -> Node3D:
    var warrior := Node3D.new()
    warrior.name = "SpartanWarrior"
    warrior.position = pos
    add_child(warrior)

    var torso := CapsuleMesh.new()
    torso.radius = 0.38
    torso.height = 1.15
    _add_mesh_part(warrior, "BronzeArmor", torso, Vector3(0.0, 1.22, 0.0), armor_color, Vector3.ZERO, Vector3(1.0, 1.0, 0.75))
    _add_sphere(warrior, "Head", 0.27, Vector3(0.0, 1.98, 0.0), Color(0.62, 0.42, 0.30))

    var helmet := SphereMesh.new()
    helmet.radius = 0.31
    helmet.height = 0.45
    _add_mesh_part(warrior, "Helmet", helmet, Vector3(0.0, 2.13, 0.0), Color(0.50, 0.39, 0.22), Vector3.ZERO, Vector3(1.1, 0.65, 1.0))
    _add_box(warrior, "HelmetNoseGuard", Vector3(0.09, 0.30, 0.12), Vector3(0.0, 1.98, 0.25), Color(0.55, 0.43, 0.24))
    _add_box(warrior, "HelmetCrest", Vector3(0.09, 0.35, 0.48), Vector3(0.0, 2.40, -0.015), crest_color)

    var arm_mesh := CylinderMesh.new()
    arm_mesh.top_radius = 0.13
    arm_mesh.bottom_radius = 0.16
    arm_mesh.height = 0.74
    _add_mesh_part(warrior, "LeftArm", arm_mesh, Vector3(-0.48, 1.30, 0.0), armor_color.darkened(0.08), Vector3(0.0, 0.0, -22.0), Vector3.ONE)
    _add_mesh_part(warrior, "RightArm", arm_mesh, Vector3(0.48, 1.30, 0.0), armor_color.darkened(0.08), Vector3(0.0, 0.0, 22.0), Vector3.ONE)

    var leg_mesh := CylinderMesh.new()
    leg_mesh.top_radius = 0.14
    leg_mesh.bottom_radius = 0.12
    leg_mesh.height = 0.72
    _add_mesh_part(warrior, "LeftLeg", leg_mesh, Vector3(-0.20, 0.38, 0.0), Color(0.22, 0.20, 0.18), Vector3.ZERO, Vector3.ONE)
    _add_mesh_part(warrior, "RightLeg", leg_mesh, Vector3(0.20, 0.38, 0.0), Color(0.22, 0.20, 0.18), Vector3.ZERO, Vector3.ONE)

    # A simple cape and waist band add silhouette detail without requiring external art assets.
    _add_box(warrior, "ClothCape", Vector3(0.66, 0.98, 0.13), Vector3(0.0, 1.21, -0.32), crest_color.darkened(0.12))
    _add_box(warrior, "BronzeWaistBand", Vector3(0.72, 0.13, 0.52), Vector3(0.0, 0.83, 0.0), Color(0.55, 0.40, 0.20))
    return warrior

func _add_mesh_part(parent: Node3D, object_name: String, mesh: Mesh, pos: Vector3, color: Color, rot_deg: Vector3, scale_value: Vector3) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    item.mesh = mesh
    item.position = pos
    item.rotation_degrees = rot_deg
    item.scale = scale_value
    item.material_override = _material(color)
    parent.add_child(item)
    return item
