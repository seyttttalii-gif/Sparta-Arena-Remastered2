# SPARTA ARENA REMASTERED — Windows 3D foundation

**Project maker:** SPARTA WORLD  
**Target:** Windows desktop, landscape 16:9  
**Engine:** Godot 4.7.2, GDScript (no .NET required)

## Important status note

This repository is a **3D foundation / first vertical slice, not the finished V57 game**. It contains a procedural 3D arena, a 13-second animated camera intro with an ATLA button, intro-on-first-run persistence, a replay-intro menu button, gentle original sound assets, settings, and a small WASD arena test. The original Pygame files are copied into `legacy_v57/` as a reference and have not been converted automatically.

World conquest, cities, sea conquest/fishing, boss fights, classic rounds, king-of-the-hill, endless mode, full character/map selection, shop/potions, achievements, multiplayer and developer systems are **not yet ported to the new 3D project**. Use `MIGRATION_STATUS.md` to track them honestly.

## Open on Windows

1. Download Godot 4.7.2 Standard (not .NET) from the official Godot website: https://godotengine.org/download/windows/ .
2. Extract the Godot ZIP to a folder. Godot is a portable executable.
3. Run `Godot_v4.7.2-stable_win64.exe`, choose **Import**, and select this folder's `project.godot`.
4. Press **F5** (Run Project) to launch the project from its intro/menu. If the editor prompts you to select a main scene, choose `scenes/main.tscn`.
5. To test the small arena, select **OYNA / MODLARI GÖR** → **3D TEKNİK ARENA TESTİ**. Move using **WASD** or arrow keys. Left-click only plays a quiet, muffled impact effect; no sword-swish clip is used.

## Windows EXE using GitHub Actions

The included `.github/workflows/windows-build.yml` installs Godot and its Windows export templates, imports the project, exports `build/SpartaArenaRemastered.exe`, then uploads it as the artifact `Sparta-Arena-Remastered-Windows`.

After pushing these files to the `main` branch (or running **Actions → Sparta Arena Remastered - Windows Build → Run workflow**), open the completed run and download its artifact. A green workflow only confirms that the project exported; it does **not** mean all V57 gameplay systems have been ported. The Godot scene and EXE have not been run in this creation environment because a Godot executable is not installed here; the first GitHub Actions run is the decisive engine/export check.

## Audio

All audio files in `assets/audio/` are original procedural tones created for this starter. UI feedback is a low, soft tap; combat feedback is a muted metallic impact. There is no sharp UI click sample and no sword-swish sound. Music/effect levels and effect mute are stored in the user's Godot settings file.

## Repository layout

- `scenes/`, `scripts/`, `assets/`: new Godot 3D project
- `.github/workflows/`: Windows EXE build
- `legacy_v57/`: source-only reference from the supplied Android-ready V57 ZIP (Python cache files excluded)
- `MIGRATION_STATUS.md`: verified source inventory and porting checklist
