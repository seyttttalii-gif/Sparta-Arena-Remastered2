# SPARTA ARENA V57 — ANDROID READY

Yapımcı: SPARTA WORLD

## Bu paket ne içeriyor?
- `app/main.py` → mevcut ana oyun
- `app/save_manager.py` → Android güvenli JSON kayıt yöneticisi
- `app/data/` → test/başlangıç JSON kayıtları
- `backend/server.py` → ayrı çalışacak sunucu başlangıcı
- `buildozer.spec` → Android debug APK yapılandırması
- `tools/build_apk.sh` → Linux ortamında APK build komutu

## Önemli
Bu paket bir **Android proje hazırlığıdır**. ZIP'i telefonda açmak APK üretmez.
APK oluşturmak için Buildozer + Android SDK/NDK destekli bir Linux ortamı gerekir.

## Test APK
Proje kökünde:
```bash
buildozer android debug
```

Başarılı olursa APK `bin/` klasöründe oluşur.

## JSON kayıtları
Uygulama için ayrı kayıtlar:
- profil
- ayarlar
- başarımlar
- dünya fethi
- deniz ilerlemesi

## Multiplayer
`backend/` APK'nin içine konulmaz. Sunucu ayrı bir bilgisayarda/VPS'te çalışır.
Gerçek internet multiplayer için sonraki aşamada WebSocket, oyuncu kimliği,
oda katılma/ayrılma, durum senkronizasyonu ve veritabanı eklenmelidir.
