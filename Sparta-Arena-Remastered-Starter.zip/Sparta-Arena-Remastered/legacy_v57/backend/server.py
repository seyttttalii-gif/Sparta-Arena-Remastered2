# SPARTA ARENA - minimal server-side room backend starter
# Production: put behind HTTPS/WSS, authentication, database and rate limits.
import json, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOMS={}
class Handler(BaseHTTPRequestHandler):
    def _json(self,obj,code=200):
        raw=json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        if self.path=="/health": return self._json({"ok":True,"service":"Sparta Arena"})
        if self.path=="/rooms": return self._json({"rooms":list(ROOMS.values())})
        return self._json({"error":"not found"},404)
    def do_POST(self):
        if self.path=="/rooms":
            room={"id":uuid.uuid4().hex[:8],"players":0,"max_players":6,"status":"waiting"}
            ROOMS[room["id"]]=room; return self._json(room,201)
        return self._json({"error":"not found"},404)

if __name__=="__main__":
    print("Sparta Arena backend starter: http://0.0.0.0:8080")
    ThreadingHTTPServer(("0.0.0.0",8080),Handler).serve_forever()
